﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;

using static System.Console;
using static System.IO.File;

namespace Exercise3Final
{
    class Program
    {
        static void Main(string[] args)
        {

            FileInfo fileToBeGZipped = new FileInfo(@"C:\Users\Trevo Ledrick\Documents\University_College_of_Østfold_2016-2019\.Net Emnet\Exercise3\Exercise3Final\exercise3.txt");
            FileInfo gzipFileName = new FileInfo(string.Concat(fileToBeGZipped.FullName, ".gz"));

            using (FileStream fileToBeZippedAsStream = fileToBeGZipped.OpenRead())
            {
                using (FileStream gzipTargetAsStream = gzipFileName.Create())
                {
                    using (GZipStream gzipStream = new GZipStream(gzipTargetAsStream, CompressionMode.Compress))
                    {
                        try
                        {
                            fileToBeZippedAsStream.CopyTo(gzipStream);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                }
            }

            
        }
    }
}
