﻿using System.Diagnostics;
using System.IO;
using System.IO.Compression;

using static System.Console;
using static System.IO.File;

namespace Exercise3
{
    class Program
    {
        static void Main(string[] args)
        {
            FileInfo fileGZipped = new FileInfo(@"C:\Users\Trevo Ledrick\Documents\University_College_of_Østfold_2016-2019\.Net Emnet\Exercise3\Exercise3\Exercise3\exercise3.txt.txt");
            FileInfo gzipFileName = new FileInfo(string.Concat(fileGZipped.FullName, ".gz"));

            //StopWatch start, to see how long it takes to compress/decompress
            var stopWatch = new Stopwatch();
            stopWatch.Restart();

            //Compression of a file
            using (FileStream fileZipStream = fileGZipped.OpenRead())
            {
                using (FileStream gzipTargetStream = gzipFileName.Create())
                {
                    using (GZipStream gZipStream = new GZipStream(gzipTargetStream, CompressionMode.Compress))
                    {
                        fileZipStream.CopyTo(gZipStream);
                    }
                }
            }

            //Stop the timing to see how long it took
            stopWatch.Stop();


            //Giving information of the process of compression
            WriteLine($"File is Compressed in {stopWatch.ElapsedMilliseconds} ms");


            //I am not sure about wheter i need another stopwatch or not
            //But I am trying anyways
            var stopWatch2 = new Stopwatch();
            stopWatch2.Restart();


            //Decompression of a file
            using (FileStream fileToGetDecompressed = gzipFileName.OpenRead())
            {
                string decompressedFileName = @"C:\Users\Trevo Ledrick\Documents\University_College_of_Østfold_2016-2019\.Net Emnet\Exercise3\Exercise3\Exercise3\exercise3.txt.txt";
                using (FileStream decompression = File.Create(decompressedFileName))
                {
                    using (GZipStream  decompressionOfFile = new GZipStream(fileToGetDecompressed, CompressionMode.Decompress))
                    {
                        decompressionOfFile.CopyTo(decompression);
                    }
                }
            }

            stopWatch2.Stop();

            //Giving information of the process of decompression
            WriteLine($"File is Compressed in {stopWatch2.ElapsedMilliseconds} ms");
        }
    }
}