﻿using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;


using static System.Console;
using static System.IO.File;
namespace Exercise3
{
    class lecture
    {
        
        static string fileName = @"C:\Users\Trevo Ledrick\source\repos\ConsoleApp1\ConsoleApp1\exercise3.txt";
        static string outPutFileName = @"C:\Users\Trevo Ledrick\source\repos\ConsoleApp1\ConsoleApp1\exercise3.gzip";

        

        static void Compress()
        {
            using (FileStream fileStream = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                using (FileStream outPutStream = new FileStream(outPutFileName, FileMode.OpenOrCreate, FileAccess.ReadWrite))
                {
                    using (GZipStream gzip = new GZipStream(fileStream, CompressionMode.Compress))
                    {
                        fileStream.CopyTo(gzip);
                    }
                }
            }
        }

        static void DeCompress()
        {

        }
        static void Main(string[] args)
        {

            Compress();

            /*var stopwatch = new Stopwatch();
            stopwatch.Restart();*/


        }
    }
}
